package com.example

object Config {

  val peopleJSONPath = "resources/people.json"

}
