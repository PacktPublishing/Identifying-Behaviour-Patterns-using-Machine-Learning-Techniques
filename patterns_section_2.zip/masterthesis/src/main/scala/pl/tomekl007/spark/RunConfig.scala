package pl.tomekl007.spark

/**
  * Created by tomasz.lelek on 16/04/16.
  */

case class RunConfig(LRNumClasses: Int = 2, W2VMinCount: Int = 0, W2VVectSize: Int = 200)


